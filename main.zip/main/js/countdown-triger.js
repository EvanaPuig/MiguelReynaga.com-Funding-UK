 			/*-----------------------------------
Full Screen Headers
 -----------------------------------*/

$(function() {
    "use strict";
    
    /* COUNTDOWN */
	$("#countdown").countdown({
		date: " 27 dec 2015 11:53:10", // Put your date here
		format: "on"
	});
	$("#coming-soon-count").countdown({
		date: " 27 dec 2015 11:53:10", // Put your date here
		format: "on"
	});
	$("#under-construction").countdown({
		date: " 27 dec 2015 11:53:10", // Put your date here
		format: "on"
	});
});